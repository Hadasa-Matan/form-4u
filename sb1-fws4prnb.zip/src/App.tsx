import React from 'react';
import SurveyForm from './components/SurveyForm';

function App() {
  return <SurveyForm />;
}

export default App;